import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_application_1/components/square_tilebig.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  // Function to handle video upload
  void _uploadVideo(BuildContext context) async {
    final ImagePicker picker = ImagePicker();
    final XFile? video = await picker.pickVideo(source: ImageSource.gallery);
    if (video != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Video selected: ${video.name}')),
      );
    }
  }

  Widget _buildHome() {
    return Column(
      children: [
        // Top part with the button
        Expanded(
          child: Center(
            child: ElevatedButton(
              onPressed: () => _uploadVideo(context),
              child: const Text('Click here to upload videos'),
            ),
          ),
        ),
        // Middle divider
        const Divider(
          color: Colors.black,
          thickness: 2,
        ),
        // Bottom part with the message
        const Expanded(
          child: Center(
            child: Text(
              'Videos will be displayed here.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildProfile() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Text(
            'Profile',
            style: TextStyle(fontSize: 32, color: Colors.white),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Text(
            'Business Name: ACS Security Group',
            style: TextStyle(fontSize: 20, color: Colors.white),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 10),
          Text(
            'Name: Hassan Hammoud',
            style: TextStyle(fontSize: 20, color: Colors.white),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 10),
          Text(
            'Contact Information: (519) 800-3947',
            style: TextStyle(fontSize: 20, color: Colors.white),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 10),
          Text(
            'Address: 2045 Astor Crescent, Tecumseh, ON N0R 1L0',
            style: TextStyle(
              fontSize: 20,
              color: Colors.white,
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 20),
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              SquareTileBig(
                imagePath: 'lib/images/logo2.png',
              ),
              const SizedBox(width: 20),
              SquareTileBig(imagePath: 'lib/images/camera.png'),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildBody(int index) {
    switch (index) {
      case 0:
        return _buildHome();
      case 2:
        return _buildProfile();
      default:
        return Container(); // Default case, should not happen in this example
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[850], // Dark grey background color
      appBar: AppBar(
        title: const Text('ACS SECURITY'),
        backgroundColor: const Color.fromARGB(255, 147, 140, 140),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              // Navigate back to the login page
              Navigator.pop(context);
            },
          ),
        ],
      ),
      body: _buildBody(_selectedIndex),
      bottomNavigationBar: BottomNavigationBar(
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        currentIndex: _selectedIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: 'Home',
            backgroundColor: Colors.black,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.search),
            label: 'Search',
            backgroundColor: Colors.black,
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: 'Profile',
            backgroundColor: Colors.black,
          ),
        ],
      ),
    );
  }
}
